package AutomationExercise;



public final class PageObject {
	private String xpathBtnMenu="//label[contains(.,'Menu')]"; // x-path for Menu button of Home page.
	private String xpathLinkOpenAnAcnt="//a[contains(.,'Open an Account')]"; //xpath for Open an Account link
	private String xpathApplyOnline ="//span[contains(.,'Apply online')]";
	private String xpathNewInvestor ="//a[contains(.,'I am a new investor')]";
	private String xpathchboxFCWPS ="(//i[contains(@class,'icon icon-check')])[1]";
	private String xpathGender ="//span[contains(.,'Female')]";
	private String xpathtitle ="//span[contains(.,'Dr')]";
	private String xpathtxtBoxGivenName ="//input[contains(@name,'givenName')]";
	private String xpathtxtBoxLastName ="//input[contains(@name,'lastName')]";
	private String xpathtxtBoxDOB ="//input[contains(@name,'dateOfBirth')]";
	private String xpathtxtBoxrAddress ="//input[contains(@id,'residential')]";
	private String xpathIsPostalY="//label[contains(@for,'input-isResPostalAdd-Y')]";
	private String xpathMobNum = "//input[contains(@name,'mobileNumber')]";
	private String xpathPermantResY="//label[contains(@for,'input-isAustralianResident-Y')]";
	private String xpathoccupation = "//input[contains(@name,'occupation')]" ;
	private String xpathpowerAttorneyY ="//label[contains(@for,'input-isPowerOfAttorney-true')]";
	private String xpathAddFundingType = "//button[contains(@id,'fypAddFundButton')]";
	private String xpathCheque="//span[contains(.,'Cheque')]";
	private String xpathFund = "//input[contains(@id,'fypOtherFundTypesAmount')]";
	private String xpathbtnDone="//button[contains(@id,'nonRolloverFormButtonDone-undefined')]";
	private String xpathApproxAmnt="//td[contains(@class,'funding-summary-total table-percent text-right ')]";
	private String xpathOptionPersonalCont="//option[contains(@value,'Personal_contribution')]";
public String getXpathBtnMenu() {
	return xpathBtnMenu;
}
public void setXpathBtnMenu(String xpathBtnMenu) {
	this.xpathBtnMenu = xpathBtnMenu;
}
public String getXpathLinkOpenAnAcnt() {
	return xpathLinkOpenAnAcnt;
}
public void setXpathLinkOpenAnAcnt(String xpathLinkOpenAnAcnt) {
	this.xpathLinkOpenAnAcnt = xpathLinkOpenAnAcnt;
}
public String getXpathApplyOnline() {
	return xpathApplyOnline;
}
public void setXpathApplyOnline(String xpathApplyOnline) {
	this.xpathApplyOnline = xpathApplyOnline;
}
public String getXpathNewInvestor() {
	return xpathNewInvestor;
}
public void setXpathNewInvestor(String xpathNewInvestor) {
	this.xpathNewInvestor = xpathNewInvestor;
}
public String getXpathchboxFCWPS() {
	return xpathchboxFCWPS;
}
public void setXpathchboxFCWPS(String xpathchboxFCWPS) {
	this.xpathchboxFCWPS = xpathchboxFCWPS;
}
public String getXpathGender() {
	return xpathGender;
}
public void setXpathGender(String xpathGender) {
	this.xpathGender = xpathGender;
}
public String getXpathtitle() {
	return xpathtitle;
}
public void setXpathtitle(String xpathtitle) {
	this.xpathtitle = xpathtitle;
}
public String getXpathtxtBoxGivenName() {
	return xpathtxtBoxGivenName;
}
public void setXpathtxtBoxGivenName(String xpathtxtBoxGivenName) {
	this.xpathtxtBoxGivenName = xpathtxtBoxGivenName;
}
public String getXpathtxtBoxLastName() {
	return xpathtxtBoxLastName;
}
public void setXpathtxtBoxLastName(String xpathtxtBoxLastName) {
	this.xpathtxtBoxLastName = xpathtxtBoxLastName;
}
public String getXpathtxtBoxDOB() {
	return xpathtxtBoxDOB;
}
public void setXpathtxtBoxDOB(String xpathtxtBoxDOB) {
	this.xpathtxtBoxDOB = xpathtxtBoxDOB;
}
public String getXpathtxtBoxrAddress() {
	return xpathtxtBoxrAddress;
}
public void setXpathtxtBoxrAddress(String xpathtxtBoxrAddress) {
	this.xpathtxtBoxrAddress = xpathtxtBoxrAddress;
}
public String getXpathIsPostalY() {
	return xpathIsPostalY;
}
public void setXpathIsPostalY(String xpathIsPostalY) {
	this.xpathIsPostalY = xpathIsPostalY;
}
public String getXpathMobNum() {
	return xpathMobNum;
}
public void setXpathMobNum(String xpathMobNum) {
	this.xpathMobNum = xpathMobNum;
}
public String getXpathPermantResY() {
	return xpathPermantResY;
}
public void setXpathPermantResY(String xpathPermantResY) {
	this.xpathPermantResY = xpathPermantResY;
}
public String getXpathoccupation() {
	return xpathoccupation;
}
public void setXpathoccupation(String xpathoccupation) {
	this.xpathoccupation = xpathoccupation;
}
public String getXpathpowerAttorneyY() {
	return xpathpowerAttorneyY;
}
public void setXpathpowerAttorneyY(String xpathpowerAttorneyY) {
	this.xpathpowerAttorneyY = xpathpowerAttorneyY;
}
public String getXpathAddFundingType() {
	return xpathAddFundingType;
}
public void setXpathAddFundingType(String xpathAddFundingType) {
	this.xpathAddFundingType = xpathAddFundingType;
}
public String getXpathCheque() {
	return xpathCheque;
}
public void setXpathCheque(String xpathCheque) {
	this.xpathCheque = xpathCheque;
}
public String getXpathFund() {
	return xpathFund;
}
public void setXpathFund(String xpathFund) {
	this.xpathFund = xpathFund;
}
/**
 * @return the xpathbtnDone
 */
public String getXpathbtnDone() {
	return xpathbtnDone;
}
/**
 * @param xpathbtnDone the xpathbtnDone to set
 */
public void setXpathbtnDone(String xpathbtnDone) {
	this.xpathbtnDone = xpathbtnDone;
}
/**
 * @return the xpathApproxAmnt
 */
public String getXpathApproxAmnt() {
	return xpathApproxAmnt;
}
/**
 * @param xpathApproxAmnt the xpathApproxAmnt to set
 */
public void setXpathApproxAmnt(String xpathApproxAmnt) {
	this.xpathApproxAmnt = xpathApproxAmnt;
}
/**
 * @return the xpathOptionPersonalCont
 */
public String getXpathOptionPersonalCont() {
	return xpathOptionPersonalCont;
}
/**
 * @param xpathOptionPersonalCont the xpathOptionPersonalCont to set
 */
public void setXpathOptionPersonalCont(String xpathOptionPersonalCont) {
	this.xpathOptionPersonalCont = xpathOptionPersonalCont;
}

}


