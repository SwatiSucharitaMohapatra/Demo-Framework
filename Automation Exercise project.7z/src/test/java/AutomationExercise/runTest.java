package AutomationExercise;
 
import java.io.File;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;
import com.cucumber.listener.Reporter;

@RunWith(Cucumber.class)


@CucumberOptions(/*plugin = {"pretty", "html:target/cucumber.reprt"},*/
					plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber.reprt/reprt.html"},
                  features = "Features\\cucumberJava.feature" ) 



public class runTest {
	
	@AfterClass
    public static void setup() {
        Reporter.loadXMLConfig(new File("src/test/resources/extent-config.xml"));
        Reporter.setSystemInfo("user", System.getProperty("user.name"));
        Reporter.setSystemInfo("os", "Windows");
        Reporter.setTestRunnerOutput("Sample test runner output message");
    }
	
}