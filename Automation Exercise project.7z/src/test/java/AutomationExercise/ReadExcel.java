package AutomationExercise;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import utilities.PageDataDriver;

//import statements
public class ReadExcel extends PageDataDriver
{
	private String fileName;
	
	public ReadExcel(String fileName)
	{
		this.fileName=fileName;
	}
	
	@Override
    public HashMap<String,String> getAllData()
    {
    	HashMap<String,String> hm =new HashMap<String,String>(); 
        String key="";
        String value="";
        int i;
        try
        {
            FileInputStream file = new FileInputStream(new File(fileName));
 
        
            HSSFWorkbook workbook = new HSSFWorkbook(file);
 
            HSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            while (rowIterator.hasNext())
            {
            	i=0;
                Row row = rowIterator.next();
       
                Iterator<Cell> cellIterator = row.cellIterator();
                 
                while (cellIterator.hasNext())
                {
                    Cell cell = cellIterator.next();
                    //Check the cell type and format accordingly
                    switch (cell.getCellType())
                    {
                       /*case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(cell.getNumericCellValue() + "");
                            break;*/
                        case Cell.CELL_TYPE_STRING:
                        	if(i==0)
                        		key = cell.getStringCellValue();
                        	if(i==1){
                        		value = cell.getStringCellValue();
                        
                            //System.out.print(cell.getStringCellValue() + " ");
                            break;
                    }
                    i++;
                }
                hm.put(key, value);
            file.close();
            }
            }
        }
        
        catch (Exception e)
        {
            e.printStackTrace();
        }
		return hm;
    }

	@Override
	public String getValue(String key) {
		// TODO Auto-generated method stub
		return null;
	}
}
