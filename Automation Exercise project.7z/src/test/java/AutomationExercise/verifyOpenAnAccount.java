package AutomationExercise; 

import java.awt.Scrollbar;
import java.util.HashMap;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.touch.ScrollAction;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.*;
import gherkin.formatter.Reporter;
import junit.framework.Assert;


public class verifyOpenAnAccount { 
   WebDriver driver = null; 
   PageObject obj = new PageObject();
   String window ;
   String key="";
   String value="";
   HashMap  exceldata= new HashMap();
   ReadExcel excel = new ReadExcel("Data\\DataSheet.xls");
   
   @Given("^I have open the browser$") 
   public void openBrowser() {
	   System.setProperty("webdriver.chrome.driver","..\\chromedriver.exe");
	   driver = new ChromeDriver();
	   driver.manage().window().maximize();
	  
	   
   } 
	
   @When("^I open colonialfirststate website$") 
   public void openUrl() { 
      driver.get("https://www3.colonialfirststate.com.au/"); 
      System.out.println("Browser opened");
   } 
	
   @Then("^Click on menu Button$") 
   public void clickMenuButton() { 
	   WebElement btnMenu = driver.findElement(By.xpath(obj.getXpathBtnMenu()));
       btnMenu.click(); 
       
      
   } 
   @Then("^Click on Open an Account link$") 
   public void clickOpenAnAccountLink() { 
	   try {
		Thread.sleep(10000);
		WebElement linkOpenAnAcnt = driver.findElement(By.xpath(obj.getXpathLinkOpenAnAcnt()));
		   linkOpenAnAcnt.click();
	} catch (InterruptedException e) {
		Assert.fail("open an Account is not present");
	}
	    
   }
   @Then("^Click on Apply Online$") 
   public void clickApplyOnline() { 
	   try {
		Thread.sleep(2000);
		WebElement btnApplyOnline = driver.findElement(By.xpath(obj.getXpathApplyOnline()));
		Actions actions = new Actions(driver);
		actions.moveToElement(btnApplyOnline);
		actions.perform();
		btnApplyOnline.click();
	} catch (InterruptedException e) {
		Assert.fail("Apply online button is not present");
	}
	    
   }
   @Then("^Click “I am a new investor”$") 
   public void clickonInvestor() { 
	   Set<String> windows = driver.getWindowHandles();
	   System.out.println("Windows -- "+windows.toString());
	  // String recentWindow ="https://secure.colonialfirststate.com.au/esetup";
	   for(String recentWindow :windows){
	   driver.switchTo().window(recentWindow);
	   System.out.println(driver.getWindowHandle().toString());
	   }
	   try {
		  Thread.sleep(2000);
		WebElement btnnewInvestor = driver.findElement(By.xpath(obj.getXpathNewInvestor()));
		btnnewInvestor.click();
	} catch (InterruptedException e) {
		Assert.fail("New investor button is button is not present");
	}
	   }
	    
   
   @Then("^Check or Click FirstChoice Wholesale Personal Super$") 
   public void selectFirstChoice() { 
	   try {
		   Thread.sleep(2000);
		WebElement chboxFCWPS = driver.findElement(By.xpath(obj.getXpathchboxFCWPS()));
		chboxFCWPS.click();
	} catch (InterruptedException e) {
		Assert.fail("FirstChoice Wholesale Personal Super check box is not present");
	}
	    
   }
   @Then("^Fill The Form And Verify the Amount$")
   public void filltheForm() throws InterruptedException { 
	   Actions actions = new Actions(driver);
	   exceldata =excel.getAllData();
	   String Name = exceldata.get("Given Name").toString().trim();
	   String lastname = exceldata.get("Last Name").toString().trim();
	   String dob = exceldata.get("Date of Birth").toString().trim();
	   String address = exceldata.get("Address").toString().trim();
	   String mobNum = exceldata.get("MobileNumber").toString().trim();
	   System.out.println(mobNum);
	   String occupation = exceldata.get("occupation").toString().trim();
	   System.out.println(occupation);
	   String amount = exceldata.get("Amount").toString().trim();
	   System.out.println(amount);
	   
		   Thread.sleep(2000);
		WebElement gender = driver.findElement(By.xpath(obj.getXpathGender()));
		gender.click();
		Thread.sleep(2000);
		WebElement title = driver.findElement(By.xpath(obj.getXpathtitle()));
		title.click();
		driver.findElement(By.xpath(obj.getXpathtxtBoxGivenName())).sendKeys(Name);
		driver.findElement(By.xpath(obj.getXpathtxtBoxLastName())).sendKeys(lastname);
		driver.findElement(By.xpath(obj.getXpathtxtBoxDOB())).sendKeys(dob);
		driver.findElement(By.xpath(obj.getXpathtxtBoxrAddress())).sendKeys(address);
		driver.findElement(By.xpath(obj.getXpathtxtBoxrAddress())).sendKeys(Keys.RETURN);
		  
		driver.findElement(By.xpath(obj.getXpathIsPostalY())).click();
		System.out.println("Mob num"+mobNum);
		driver.findElement(By.xpath(obj.getXpathMobNum())).sendKeys("0"+mobNum);
		driver.findElement(By.xpath(obj.getXpathPermantResY())).click();
		driver.findElement(By.xpath(obj.getXpathoccupation())).sendKeys(occupation);
		driver.findElement(By.xpath(obj.getXpathpowerAttorneyY())).click();
		driver.findElement(By.xpath(obj.getXpathAddFundingType())).click();
		Thread.sleep(2000);
		actions.moveToElement(driver.findElement(By.id("fypFundingTypeDropdown")));
		actions.perform();
		driver.findElement(By.id("fypFundingTypeDropdown")).click();
		/*Select dropdown = new Select(driver.findElement(By.id("fypFundingTypeDropdown")));
		Thread.sleep(2000);
		dropdown.selectByVisibleText("Personal Contribution");*/
		
	Thread.sleep(2000);
		driver.findElement(By.xpath(obj.getXpathOptionPersonalCont())).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(obj.getXpathCheque())).click();
		driver.findElement(By.xpath(obj.getXpathFund())).sendKeys(amount);
		driver.findElement(By.xpath(obj.getXpathbtnDone())).click();
		Thread.sleep(1000);
		System.out.println("--------"+driver.findElement(By.xpath(obj.getXpathApproxAmnt())));
		System.out.println("--------"+driver.findElement(By.xpath(obj.getXpathApproxAmnt())).getText());
		String ApproxAmout =driver.findElement(By.xpath(obj.getXpathApproxAmnt())).getText();
	
		verifyAmount(ApproxAmout);
   }
    
   public void verifyAmount(String actualAmount) { 
	 if(actualAmount.contains("$100.00")){
			
			Assert.assertTrue("Expected Amount is not mathcing", true);
			System.out.println("validation passed");
} 
	   
   }
   
   @Then("^Close Window$") 
   public void closeWindow() { 
	   driver.close();
	   Set<String> windows = driver.getWindowHandles();
	   for(String recentWindow :windows){
		driver.switchTo().window(recentWindow);
	   driver.close();
	   }
	   
   }
	    
   }
   
