package utilities;

import java.util.HashMap;

public abstract class PageDataDriver {
	
	
	public abstract HashMap<String,String> getAllData();
	
	public abstract String getValue(String key); 

}
